package com.jobportal.Entities;

public enum Role {

	ROLE_CANDIDATE,
	ROLE_RECRUITER
}
