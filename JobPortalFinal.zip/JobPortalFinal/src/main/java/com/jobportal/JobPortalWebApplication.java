package com.jobportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobPortalWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobPortalWebApplication.class, args);
	}

}
